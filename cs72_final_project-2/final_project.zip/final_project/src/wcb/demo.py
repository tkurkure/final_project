"""Gradio demo: paste a central-bank statement, get a sentence-by-sentence stance read.

Run with:
    python -m wcb.demo                      # TF-IDF backend, trains in ~10s
    python -m wcb.demo --backend roberta --checkpoint results/roberta/pooled_model

Design commitments, both of which come straight from the project's stated risk -- that
someone trusts a confident-looking score for a bank the model reads badly:

  * The score is never shown alone. Every document score is displayed next to the
    sentences it was computed from, so a reader can always check the arithmetic.
  * A bank outside the 25 training banks triggers a prominent warning, because that is
    exactly the leave-one-bank-out condition this project measures, and we know it costs
    about 5 points of weighted F1 on average -- far more for some banks.
"""
from __future__ import annotations

import argparse
import html
import logging
import re
from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd

from . import config as C
from .logging_utils import setup_logging

logger = logging.getLogger(__name__)

OTHER_BANK = "— other / not in the dataset —"

# Diverging pair for the two opposed policy stances, plus recessive neutrals.
STANCE_COLORS = {
    "hawkish": "#e34948",
    "dovish": "#2a78d6",
    "neutral": "#6b6a66",
    "irrelevant": "#a8a7a2",
}

# Fraction of the least-confident validation sentences to flag. Calibrated against the
# validation split rather than guessed, and the measured accuracy either side of the
# threshold is logged so the number means something.
FLAG_FRACTION = 0.15


# ---------------------------------------------------------------------------------
# Sentence splitting
# ---------------------------------------------------------------------------------
_ABBREV = r"(?<!\bU\.S)(?<!\be\.g)(?<!\bi\.e)(?<!\bMr)(?<!\bMs)(?<!\bDr)(?<!\bNo)(?<!\bvs)"
_FALLBACK_SPLIT = re.compile(rf"{_ABBREV}(?<=[.!?])\s+(?=[A-Z(])")


def split_sentences(text: str) -> List[str]:
    """Split a pasted document into sentences.

    Prefers NLTK's punkt, which handles the decimals ("2.5 percent") and abbreviations
    ("the U.S. economy") that are everywhere in this domain; falls back to a guarded
    regex when the punkt data is not downloadable (e.g. an offline cluster node).
    """
    text = text.strip()
    if not text:
        return []
    try:
        from nltk.tokenize import sent_tokenize
        return [s.strip() for s in sent_tokenize(text) if s.strip()]
    except Exception:
        logger.warning("punkt unavailable -- using the regex sentence splitter")
        return [s.strip() for s in _FALLBACK_SPLIT.split(text) if s.strip()]


# ---------------------------------------------------------------------------------
# Backends
# ---------------------------------------------------------------------------------
@dataclass
class Prediction:
    sentence: str
    label: str
    confidence: float
    low_confidence: bool


class Backend:
    """Anything that can turn sentences into stance probabilities."""
    name = "base"

    def predict_proba(self, sentences: List[str]) -> np.ndarray:
        raise NotImplementedError


class BaselineBackend(Backend):
    """TF-IDF + logistic regression, fit on the pooled training split at startup.

    Fast enough (~10s) that the demo is runnable before any GPU work exists, and it is
    the documented fallback if GPU access falls through.
    """
    name = "tfidf"

    def __init__(self, frames):
        from .baseline import build_pipeline
        from .splits import pooled_fold

        fold = pooled_fold(frames)
        logger.info("fitting TF-IDF baseline on %d sentences ...", len(fold.train))
        self.pipe = build_pipeline()
        self.pipe.fit(fold.train[C.TEXT_COLUMN], fold.train["stance_id"])
        self.classes = self.pipe.named_steps["clf"].classes_

    def predict_proba(self, sentences: List[str]) -> np.ndarray:
        raw = self.pipe.predict_proba(sentences)
        full = np.zeros((len(sentences), len(C.STANCE_LABELS)))
        for col, cls in enumerate(self.classes):
            full[:, int(cls)] = raw[:, col]
        return full


class RobertaBackend(Backend):
    """A fine-tuned RoBERTa checkpoint saved by scripts/run_roberta.py."""
    name = "roberta"

    def __init__(self, checkpoint: str, device: Optional[str] = None):
        import torch
        from transformers import AutoModelForSequenceClassification, AutoTokenizer
        from .train import get_device

        self.device = device or get_device()
        self.tokenizer = AutoTokenizer.from_pretrained(checkpoint)
        self.model = AutoModelForSequenceClassification.from_pretrained(checkpoint)
        self.model.to(self.device).eval()
        self.torch = torch

    def predict_proba(self, sentences: List[str]) -> np.ndarray:
        torch = self.torch
        out = []
        with torch.no_grad():
            for i in range(0, len(sentences), 32):
                enc = self.tokenizer(sentences[i:i + 32], padding=True, truncation=True,
                                     max_length=C.DEFAULT_HPARAMS["max_length"],
                                     return_tensors="pt").to(self.device)
                logits = self.model(**enc).logits
                out.append(torch.softmax(logits.float(), -1).cpu().numpy())
        return np.concatenate(out)


# ---------------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------------
def calibrate_threshold(backend: Backend, frames, fraction: float = FLAG_FRACTION) -> float:
    """Pick the confidence cutoff from the validation split, and verify it separates.

    Flags the least-confident `fraction` of validation sentences, then logs accuracy
    above and below the cutoff. If those two numbers are close, the flag is decoration
    and the log says so.
    """
    val = frames["val"]
    probs = backend.predict_proba(val[C.TEXT_COLUMN].tolist())
    conf = probs.max(axis=1)
    threshold = float(np.quantile(conf, fraction))

    correct = probs.argmax(axis=1) == val["stance_id"].values
    below, above = conf < threshold, conf >= threshold
    acc_below = correct[below].mean() if below.any() else float("nan")
    acc_above = correct[above].mean() if above.any() else float("nan")
    logger.info("confidence threshold %.3f (flags %.0f%% of val): "
                "accuracy %.1f%% below vs %.1f%% above",
                threshold, 100 * fraction, 100 * acc_below, 100 * acc_above)
    return threshold


def document_score(preds: List[Prediction]) -> Tuple[float, int, int, int]:
    """(hawkish - dovish) / (sentences excluding irrelevant), in [-1, +1]."""
    hawk = sum(p.label == "hawkish" for p in preds)
    dove = sum(p.label == "dovish" for p in preds)
    relevant = sum(p.label != "irrelevant" for p in preds)
    score = (hawk - dove) / relevant if relevant else 0.0
    return score, hawk, dove, relevant


def analyze(text: str, backend: Backend, threshold: float) -> List[Prediction]:
    sentences = split_sentences(text)
    if not sentences:
        return []
    probs = backend.predict_proba(sentences)
    out = []
    for sent, row in zip(sentences, probs):
        i = int(row.argmax())
        conf = float(row[i])
        out.append(Prediction(sent, C.ID2STANCE[i], conf, conf < threshold))
    return out


# ---------------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------------
def render(preds: List[Prediction], bank: str, backend_name: str) -> str:
    if not preds:
        return "<p style='color:#52514e'>Paste a statement to analyse.</p>"

    score, hawk, dove, relevant = document_score(preds)
    unseen = bank == OTHER_BANK

    direction = "hawkish" if score > 0.05 else "dovish" if score < -0.05 else "balanced"
    colour = (STANCE_COLORS["hawkish"] if score > 0.05
              else STANCE_COLORS["dovish"] if score < -0.05 else STANCE_COLORS["neutral"])

    parts = [
        "<div style=\"font-family:ui-sans-serif,system-ui,sans-serif;color:#0b0b0b\">"
    ]

    if unseen:
        parts.append(
            "<div style=\"border-left:4px solid #eb6834;background:#fdf1ea;"
            "padding:10px 14px;margin-bottom:14px;border-radius:4px\">"
            "<strong>This bank is not one of the 25 the model was trained on.</strong><br>"
            "<span style='color:#52514e;font-size:0.92em'>"
            "Leave-one-bank-out testing shows accuracy falls by about 5 points of "
            "weighted F1 on an unseen bank on average, and by far more for banks whose "
            "wording is unusual. Treat this reading as indicative only.</span></div>")

    parts.append(
        f"<div style=\"display:flex;align-items:baseline;gap:14px;margin-bottom:4px\">"
        f"<span style='font-size:2.1em;font-weight:600;color:{colour}'>{score:+.2f}</span>"
        f"<span style='color:#52514e'>document stance score &middot; "
        f"<strong>{direction}</strong></span></div>"
        f"<div style='color:#52514e;font-size:0.9em;margin-bottom:14px'>"
        f"{hawk} hawkish &minus; {dove} dovish over {relevant} policy-relevant "
        f"sentences ({len(preds)} total). Backend: {backend_name}.</div>")

    # Legend -- identity is never carried by colour alone; each sentence is also
    # labelled in text below.
    parts.append("<div style='margin-bottom:10px;font-size:0.85em'>")
    for label, col in STANCE_COLORS.items():
        parts.append(
            f"<span style='display:inline-block;margin-right:12px'>"
            f"<span style='display:inline-block;width:10px;height:10px;background:{col};"
            f"border-radius:2px;margin-right:5px'></span>{label}</span>")
    parts.append("</div>")

    parts.append("<div style='border-top:1px solid #e4e3df;padding-top:10px'>")
    for i, p in enumerate(preds, 1):
        col = STANCE_COLORS[p.label]
        flag = ("<span style='color:#eb6834;font-weight:600' "
                "title='Model confidence is in the lowest 15% seen on validation data'>"
                " &#9888; low confidence</span>" if p.low_confidence else "")
        parts.append(
            f"<div style='margin:0 0 9px 0;padding-left:10px;border-left:3px solid {col}'>"
            f"<div style='font-size:0.78em;color:#52514e;margin-bottom:2px'>"
            f"{i}. <strong style='color:{col}'>{p.label}</strong> "
            f"&middot; {p.confidence:.0%} confident{flag}</div>"
            f"<div>{html.escape(p.sentence)}</div></div>")
    parts.append("</div></div>")
    return "".join(parts)


EXAMPLE = (
    "The Committee judges that inflation remains elevated and that risks to price "
    "stability are tilted to the upside. Accordingly, the Committee decided to raise "
    "the target range for the policy rate by 25 basis points. Economic activity has "
    "continued to expand at a moderate pace, although growth in business investment "
    "has slowed. The Committee will continue to monitor incoming data and stands ready "
    "to adjust the stance of policy as appropriate. The next meeting is scheduled for "
    "15 March."
)


def build_app(backend: Backend, threshold: float, frames):
    import gradio as gr

    bank_choices = [C.BANK_DISPLAY_NAMES[b] for b in C.BANKS] + [OTHER_BANK]

    def run(text, bank):
        return render(analyze(text, backend, threshold), bank, backend.name)

    with gr.Blocks(title="Central Bank Stance Reader") as app:
        gr.Markdown(
            "# Central Bank Stance Reader\n"
            "Paste a monetary policy statement. Each sentence is classified as "
            "**hawkish**, **dovish**, **neutral** or **irrelevant**, and combined into a "
            "document score from &minus;1 (dovish) to +1 (hawkish).\n\n"
            "Pick the issuing central bank — if it is not one of the 25 in the training "
            "data, the reading comes with a warning, because that is measurably the "
            "harder case.")
        with gr.Row():
            with gr.Column(scale=3):
                text = gr.Textbox(label="Statement", lines=12, value=EXAMPLE)
            with gr.Column(scale=2):
                bank = gr.Dropdown(bank_choices, value=OTHER_BANK, label="Issuing central bank")
                go = gr.Button("Analyse", variant="primary")
        out = gr.HTML()
        go.click(run, [text, bank], out)
        text.submit(run, [text, bank], out)
        app.load(run, [text, bank], out)
    return app


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", choices=["baseline", "roberta"], default="baseline")
    ap.add_argument("--checkpoint", default=None, help="path to a fine-tuned RoBERTa dir")
    ap.add_argument("--seed", type=int, default=C.PRIMARY_SEED)
    ap.add_argument("--share", action="store_true")
    ap.add_argument("--port", type=int, default=7860)
    args = ap.parse_args()

    setup_logging()
    from .data import load_annotated

    frames = load_annotated(args.seed)

    if args.backend == "roberta":
        if not args.checkpoint:
            ap.error("--backend roberta requires --checkpoint")
        backend = RobertaBackend(args.checkpoint)
    else:
        backend = BaselineBackend(frames)

    threshold = calibrate_threshold(backend, frames)
    build_app(backend, threshold, frames).launch(
        server_port=args.port, share=args.share)


if __name__ == "__main__":
    main()
